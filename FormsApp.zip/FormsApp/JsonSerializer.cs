﻿using Newtonsoft.Json;
using PointLib;
using System;
using System.IO;

namespace FormsApp
{
    //internal class JsonSerializer
    //{
    //    public TypeNameHandling TypeNameHandling { get; internal set; }

    //    public JsonSerializer()
    //    {
    //    }

    //    //internal void Serialize(StreamWriter w, Point[] points)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}

    //    //internal Point[] Deserialize(StreamReader r, Type type)
    //    //{
    //    //    throw new NotImplementedException();
    //    //}
    //}
}